open ReM
open Dst
open Parser_plaf.Ast
open Parser_plaf.Parser
       
let rec chk_expr : expr -> texpr tea_result = function 
  | Int _n -> return IntType
  | Var id -> apply_tenv id
  | IsZero(e) ->
    chk_expr e >>= fun t ->
    if t=IntType
    then return BoolType
    else error "isZero: expected argument of type int"
  | Add(e1,e2) | Sub(e1,e2) | Mul(e1,e2)| Div(e1,e2) ->
    chk_expr e1 >>= fun t1 ->
    chk_expr e2 >>= fun t2 ->
    if (t1=IntType && t2=IntType)
    then return IntType
    else error "arith: arguments must be ints"
  | ITE(e1,e2,e3) ->
    chk_expr e1 >>= fun t1 ->
    chk_expr e2 >>= fun t2 ->
    chk_expr e3 >>= fun t3 ->
    if (t1=BoolType && t2=t3)
    then return t2
    else error "ITE: condition not boolean or types of then and else do not match"
  | Let(id,e,body) ->
    chk_expr e >>= fun t ->
    extend_tenv id t >>+
    chk_expr body
  | Proc(var,Some t1,e) ->
    extend_tenv var t1 >>+
    chk_expr e >>= fun t2 ->
    return @@ FuncType(t1,t2)
  | Proc(_var,None,_e) ->
    error "proc: type declaration missing"
  | App(e1,e2) ->
    chk_expr e1 >>=
    pair_of_funcType "app: " >>= fun (t1,t2) ->
    chk_expr e2 >>= fun t3 ->
    if t1=t3
    then return t2
    else error "app: type of argument incorrect"
  | Letrec([(_id,_param,None,_,_body)],_target) | Letrec([(_id,_param,_,None,_body)],_target) ->
    error "letrec: type declaration missing"
  | Letrec([(id,param,Some tParam,Some tRes,body)],target) ->
    extend_tenv id (FuncType(tParam,tRes)) >>+
    (extend_tenv param tParam >>+
     chk_expr body >>= fun t ->
     if t=tRes 
     then chk_expr target
     else error
         "LetRec: Type of recursive function does not match
declaration")

  (* Type-Checking References *)
  | NewRef(e) ->
    (* Type-check expression e *)
    chk_expr e >>= fun t ->
    (* Return reference type *)
    return (RefType(t))
  | DeRef(e) ->
    (* Type-check expression e *)
    chk_expr e >>= fun t ->
    (* Ensure type is a reference, return type *)
    (match t with
     | RefType(t1) -> return t1
     | _ -> error "deref: Expected a reference type")
  | SetRef(e1, e2) ->
    (* Type-check both expressions *)
    chk_expr e1 >>= fun t1 ->
    chk_expr e2 >>= fun t2 ->
    (* Ensure e1 is a reference and that it matches e2's type *)
    (match t1 with
     | RefType contained_type ->
        if contained_type = t2
        then return UnitType
        else error "setref : Expected contained reference type"
     | _ -> error "setref : Expected a reference type")
  | BeginEnd([]) -> return UnitType
  | BeginEnd(es) ->
    let rec eval_exprs exprs = 
    match exprs with
    (* Return the unit type if there are no more expressions left *)
    | [] -> return UnitType 
    (* Return type of remaining expression *)
    | [last] -> chk_expr last  
    (* Evaluate each expression *)
    | expr :: tail -> 
      chk_expr expr >>= fun _ -> eval_exprs tail  
    in
    eval_exprs es

  (* Lists *)
  | EmptyList(None) -> return (ListType UnitType) 
  | EmptyList(Some t) -> return (ListType t)
  | Cons(e1, e2) ->
    (* Type check e1 and e2 *)
    chk_expr e1 >>= fun hd -> 
    chk_expr e2 >>= fun tl -> 
    (* Ensure tail is list type and that head's type matches *)   
    (match tl with
     | ListType t ->  
        if t = hd then return (ListType t)  
        else error "cons: type of head and tail do not match"
     | _ -> error "cons: second argument must be a list") 
  | IsEmpty(e) ->
    (* Type check e *)
    chk_expr e >>= fun t ->
    (* If expression is list or tree, return BoolType *)
    (match t with
     | ListType _ -> return BoolType
     | TreeType _ -> return BoolType
     (* Return error otherwise *)
     | _ -> error "isempty: Expected a list type")
  | Hd(e) ->
    (* Type check e *)
    chk_expr e >>= fun t ->
    (* Ensure type is list *)
    (match t with
     | ListType t1 -> return t1
     | _ -> error "hd: Expected a list type")
  | Tl(e) ->
    (* Type check e *)
    chk_expr e >>= fun t ->
    (* Ensure the type is list *)
    (match t with
     | ListType t1 -> return (ListType t1)
     | _ -> error "tl: Expected a list type")


  (* Trees *)
  | EmptyTree(None) -> return (TreeType UnitType)  
  | EmptyTree(Some t) -> return (TreeType t)
  | Node(de, le, re) ->
    (* Type-check value and both subtree expressions *)
    chk_expr de >>= fun t1 -> 
    chk_expr le >>= fun t2 ->  
    chk_expr re >>= fun t3 ->  
    (* Ensure both subtrees have same type *)
    (match t2 with
     | _ when t2 = t3 -> return (TreeType t1)  
     | _ -> error "node: Both subtrees must have the same type")
  | CaseT (target, emptycase, id1, id2, id3, nodecase) ->
    (* Type-check target expression and emptycase *)
    chk_expr target >>= fun t ->
    chk_expr emptycase >>= fun empty_case ->
    (match t with
     | TreeType d -> 
       (* Extend environment *)
       extend_tenv id1 d >>+
       extend_tenv id2 t >>+
       extend_tenv id3 t >>+
       (* Type-check nodecase *)
       chk_expr nodecase >>= fun node_case ->
       (* Ensure types match *)
       (match empty_case, node_case with
        | type1, type2 when type1 = type2 -> return type1
        | _ -> error "caset: type of emptycase does not match type of nodecase")
     | _ -> error "caset: target must be a node")


  | Debug(_e) ->
    string_of_tenv >>= fun str ->
    print_endline str;
    error "Debug: reached breakpoint"
  | _ -> failwith "chk_expr: implement"    
and
  chk_prog (AProg(_,e)) =
  chk_expr e

(* Type-check an expression *)
let chk (e:string) : texpr result =
  let c = e |> parse |> chk_prog
  in run_teac c

let chkpp (e:string) : string result =
  let c = e |> parse |> chk_prog
  in run_teac (c >>= fun t -> return @@ string_of_texpr t)

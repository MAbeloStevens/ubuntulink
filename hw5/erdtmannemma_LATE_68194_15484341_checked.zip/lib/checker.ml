(* Emma Erdtmann and Hans Iselborn *)
(* I pledge my honor that I have abided by the Stevens Honor System. *)
open ReM
open Dst
open Parser_plaf.Ast
open Parser_plaf.Parser
       
let rec chk_expr : expr -> texpr tea_result = function 
  | Int _n -> return IntType
  | Var id -> apply_tenv id
  | IsZero(e) ->
    chk_expr e >>= fun t ->
    if t=IntType
    then return BoolType
    else error "isZero: expected argument of type int"
  | Add(e1,e2) | Sub(e1,e2) | Mul(e1,e2)| Div(e1,e2) ->
    chk_expr e1 >>= fun t1 ->
    chk_expr e2 >>= fun t2 ->
    if (t1=IntType && t2=IntType)
    then return IntType
    else error "arith: arguments must be ints"
  | ITE(e1,e2,e3) ->
    chk_expr e1 >>= fun t1 ->
    chk_expr e2 >>= fun t2 ->
    chk_expr e3 >>= fun t3 ->
    if (t1=BoolType && t2=t3)
    then return t2
    else error "ITE: condition not boolean or types of then and else do not match"
  | Let(id,e,body) ->
    chk_expr e >>= fun t ->
    extend_tenv id t >>+
    chk_expr body
  | Proc(var,Some t1,e) ->
    extend_tenv var t1 >>+
    chk_expr e >>= fun t2 ->
    return @@ FuncType(t1,t2)
  | Proc(_var,None,_e) ->
    error "proc: type declaration missing"
  | App(e1,e2) ->
    chk_expr e1 >>=
    pair_of_funcType "app: " >>= fun (t1,t2) ->
    chk_expr e2 >>= fun t3 ->
    if t1=t3
    then return t2
    else error "app: type of argument incorrect"
  | Letrec([(_id,_param,None,_,_body)],_target) | Letrec([(_id,_param,_,None,_body)],_target) ->
    error "letrec: type declaration missing"
  | Letrec([(id,param,Some tParam,Some tRes,body)],target) ->
    extend_tenv id (FuncType(tParam,tRes)) >>+
    (extend_tenv param tParam >>+
     chk_expr body >>= fun t ->
     if t=tRes 
     then chk_expr target
     else error
         "LetRec: Type of recursive function does not match
declaration")
  (* HW 5 PART 1: TYPE-CHECKING FOR REFERENCES *)
  | NewRef(e) -> chk_expr e >>= fun t1 ->
    return @@ RefType(t1)
  | DeRef(e) -> chk_expr e >>= fun t1 ->
    begin
    match t1 with
    | RefType(t2) -> return t2
    | _ -> error "deref: Expected a reference type"
    end
  | SetRef(e1, e2) -> chk_expr e1 >>= fun t1 -> (* UNUSED e2 *)
    begin
      match t1 with
      | RefType(_) -> return UnitType
      | _ -> error "setref: Expected a reference type"
    end
  | BeginEnd([]) -> return UnitType
  | BeginEnd(es) ->
    sequence (List.map chk_expr es) >>= fun t ->
    return (List.hd (List.rev t))  
  (* HW 5 PART 2: TYPE-CHECKING FOR LISTS *)
  | EmptyList(t) -> 
      begin
      match t with
      | Some t1 -> return @@ ListType(t1)
      | None -> error "emptylist: must provide type"
      end
  | Cons(e1, e2) -> chk_expr e2 >>= fun t ->
    chk_expr e1 >>= fun t2 ->
    begin
      match t with
      | ListType(t1) -> 
          if t1 = t2 then return @@ ListType(t1)
          else error "cons: type of head and tail do not match"
      | _ -> error "cons: second argument must be a list"
    end
  | IsEmpty(e) -> chk_expr e >>= fun t ->
    begin
    match t with
    | ListType(_) -> return BoolType
    | TreeType(_) -> return BoolType
    | _ -> error "isempty: argument must be a list"
    end
  | Hd(e) -> chk_expr e >>= fun t ->
    begin
      match t with
      | ListType(t1) -> return t1
      | _ -> error "hd: argument must be a list"
    end
  | Tl(e) -> chk_expr e >>= fun t ->
    begin
      match t with
      | ListType(t1) -> return @@ ListType(t1)
      | _ -> error "tl: argument must be a list"
    end
  (* HW 5 PART 3: TYPE-CHECKING FOR TREES *)
  | EmptyTree(t)
   -> 
    begin
      match t with
      | Some t1 -> return @@ TreeType(t1)
      | None -> error "emptytree: must provide type"
      end
  | Node(de, le, re) -> chk_expr de >>= fun t1 ->
    chk_expr le >>= fun tl ->
    chk_expr re >>= fun tr ->
      begin
        match tl, tr with
        | TreeType(t2), TreeType(t3) -> if t1 = t2 && t2 = t3 then return @@ TreeType(t1)
        else error "node: all arguments must have the same type"
        | _ -> error "node: second and third arguments must be of type tree"
      end
  | CaseT(e, empty_case, d, lt, rt, node_case) ->
    chk_expr e >>= fun t ->
    begin
      match t with
      | TreeType(t_elem) ->
          chk_expr empty_case >>= fun t_empty ->
          extend_tenv d t_elem >>+
          extend_tenv lt (TreeType t_elem) >>+
          extend_tenv rt (TreeType t_elem) >>+
          chk_expr node_case >>= fun t_node ->
          if t_empty = t_node then return t_empty
          else error "caseT: branches must return the same type"
      | _ -> error "caseT: expected a tree"
      end    
  (* END OF HW 5 STUFF *)
  | Debug(_e) ->
      string_of_tenv >>= fun str ->
      print_endline str;
      error "Debug: reached breakpoint"
    | _ -> failwith "chk_expr: implement"    
  and
    chk_prog (AProg(_,e)) =
    chk_expr e

(* Type-check an expression *)
let chk (e:string) : texpr result =
  let c = e |> parse |> chk_prog
  in run_teac c

let chkpp (e:string) : string result =
  let c = e |> parse |> chk_prog
  in run_teac (c >>= fun t -> return @@ string_of_texpr t)




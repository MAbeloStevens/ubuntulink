open ReM
open Dst
open Parser_plaf.Ast
open Parser_plaf.Parser
       
let rec chk_expr : expr -> texpr tea_result = function 
  | Int _n -> return IntType
  | Var id -> apply_tenv id
  | IsZero(e) ->
    chk_expr e >>= fun t ->
    if t=IntType
    then return BoolType
    else error "isZero: expected argument of type int"
  | Add(e1,e2) | Sub(e1,e2) | Mul(e1,e2)| Div(e1,e2) ->
    chk_expr e1 >>= fun t1 ->
    chk_expr e2 >>= fun t2 ->
    if (t1=IntType && t2=IntType)
    then return IntType
    else error "arith: arguments must be ints"
  | ITE(e1,e2,e3) ->
    chk_expr e1 >>= fun t1 ->
    chk_expr e2 >>= fun t2 ->
    chk_expr e3 >>= fun t3 ->
    if (t1=BoolType && t2=t3)
    then return t2
    else error "ITE: condition not boolean or types of then and else do not match"
  | Let(id,e,body) ->
    chk_expr e >>= fun t ->
    extend_tenv id t >>+
    chk_expr body
  | Proc(var,Some t1,e) ->
    extend_tenv var t1 >>+
    chk_expr e >>= fun t2 ->
    return @@ FuncType(t1,t2)
  | Proc(_var,None,_e) ->
    error "proc: type declaration missing"
  | App(e1,e2) ->
    chk_expr e1 >>=
    pair_of_funcType "app: " >>= fun (t1,t2) ->
    chk_expr e2 >>= fun t3 ->
    if t1=t3
    then return t2
    else error "app: type of argument incorrect"
  | Letrec([(_id,_param,None,_,_body)],_target) | Letrec([(_id,_param,_,None,_body)],_target) ->
    error "letrec: type declaration missing"
  | Letrec([(id,param,Some tParam,Some tRes,body)],target) ->
    extend_tenv id (FuncType(tParam,tRes)) >>+
    (extend_tenv param tParam >>+
     chk_expr body >>= fun t ->
     if t=tRes 
     then chk_expr target
     else error
         "LetRec: Type of recursive function does not match
declaration")
  | Debug(_e) ->
    string_of_tenv >>= fun str ->
    print_endline str;
    error "Debug: reached breakpoint"
    (* HW5 *)

  | NewRef ( e ) -> 
    chk_expr e >>= fun t ->
    return (RefType t)

  | DeRef ( e ) -> 
    chk_expr e >>= fun t ->
      (match t with
       | RefType(x) -> return x
       | _ -> error "deref: Expected a reference type")

  | SetRef(e1, e2) ->
    chk_expr e1 >>= fun t1 ->
    chk_expr e2 >>= fun t2 ->
    (match t1 with
     | RefType(x) ->
         if x = t2
         then return UnitType
         else error "setref: Type mismatch"
     | _ -> error "setref: Expected a reference type")

  | BeginEnd([]) ->
    return UnitType

  | BeginEnd(es) ->
    let rec last_type = function
      | [] -> error "begin-end: empty block"
      | [e] -> chk_expr e
      | e::rest -> chk_expr e >>= fun _ -> last_type rest
    in last_type es


  | EmptyList(t) ->
    (match t with
    | Some x -> return (ListType x)
    | None -> error "emptylist: type annotation missing")
  
  | Cons(e1, e2) ->
    chk_expr e1 >>= fun head_type ->
    chk_expr e2 >>= fun tail_type ->
    (match tail_type with
      | ListType(x) when x = head_type -> return tail_type
      | ListType(_) -> error "cons: type of head and tail do not match"
      | _ -> error "cons: second argument must be a list")
  
  | IsEmpty(e) ->
    chk_expr e >>= fun t ->
    (match t with
      | ListType(_) -> return BoolType
      | TreeType(_) -> return BoolType
      | _ -> error "empty?: expected a list or tree")
  
  | Hd(e) ->
    chk_expr e >>= fun t ->
    (match t with
      | ListType(x) -> return x
      | _ -> error "hd: expected a list")
  
  | Tl(e) ->
    chk_expr e >>= fun t ->
    (match t with
      | ListType(_) -> return t
      | _ -> error "tl: expected a list")
  

  | EmptyTree(t) ->
    (match t with
    | Some x -> return (TreeType x)
    | None -> error "emptytree: type annotation missing")
        
    
  | Node(de, le, re) ->
      chk_expr de >>= fun node_type ->
      chk_expr le >>= fun left_type ->
      chk_expr re >>= fun right_type ->
      (match left_type, right_type with
        | TreeType(x), TreeType(y) when x = node_type && y = node_type ->
            return (TreeType node_type)
        | _ -> error "node: subtrees must be tree(t) matching data type")
    
  
    
  | CaseT(target, emptycase, id1, id2, id3, nodecase) ->
        chk_expr target >>= fun target_type ->
        (match target_type with
         | TreeType(t) ->
             chk_expr emptycase >>= fun empty_type ->
             extend_tenv id1 t >>+
             extend_tenv id2 (TreeType t) >>+
             extend_tenv id3 (TreeType t) >>+
             chk_expr nodecase >>= fun node_type ->
             if empty_type = node_type then return empty_type
             else error "caseT: types of branches do not match"
         | _ -> error "caseT: target is not a tree")



  | _ -> failwith "chk_expr: implement"    
and
  chk_prog (AProg(_,e)) =
  chk_expr e

(* Type-check an expression *)
let chk (e:string) : texpr result =
  let c = e |> parse |> chk_prog
  in run_teac c

let chkpp (e:string) : string result =
  let c = e |> parse |> chk_prog
  in run_teac (c >>= fun t -> return @@ string_of_texpr t)




(* Payton Bates - I pledge my honor that I have abided by the Stevens Honor System *)

open ReM
open Dst
open Parser_plaf.Ast
open Parser_plaf.Parser
       
let rec chk_expr : expr -> texpr tea_result = function 
  | Int _n -> return IntType
  | Var id -> apply_tenv id
  | IsZero(e) ->
    chk_expr e >>= fun t ->
    if t=IntType
    then return BoolType
    else error "isZero: expected argument of type int"
  | Add(e1,e2) | Sub(e1,e2) | Mul(e1,e2)| Div(e1,e2) ->
    chk_expr e1 >>= fun t1 ->
    chk_expr e2 >>= fun t2 ->
    if (t1=IntType && t2=IntType)
    then return IntType
    else error "arith: arguments must be ints"
  | ITE(e1,e2,e3) ->
    chk_expr e1 >>= fun t1 ->
    chk_expr e2 >>= fun t2 ->
    chk_expr e3 >>= fun t3 ->
    if (t1=BoolType && t2=t3)
    then return t2
    else error "ITE: condition not boolean or types of then and else do not match"
  | Let(id,e,body) ->
    chk_expr e >>= fun t ->
    extend_tenv id t >>+
    chk_expr body
  | Proc(var,Some t1,e) ->
    extend_tenv var t1 >>+
    chk_expr e >>= fun t2 ->
    return @@ FuncType(t1,t2)
  | Proc(_var,None,_e) ->
    error "proc: type declaration missing"
  | App(e1,e2) ->
    chk_expr e1 >>=
    pair_of_funcType "app: " >>= fun (t1,t2) ->
    chk_expr e2 >>= fun t3 ->
    if t1=t3
    then return t2
    else error "app: type of argument incorrect"
  | Letrec([(_id,_param,None,_,_body)],_target) | Letrec([(_id,_param,_,None,_body)],_target) ->
    error "letrec: type declaration missing"
  | Letrec([(id,param,Some tParam,Some tRes,body)],target) ->
    extend_tenv id (FuncType(tParam,tRes)) >>+
    (extend_tenv param tParam >>+
     chk_expr body >>= fun t ->
     if t=tRes 
     then chk_expr target
     else error
         "LetRec: Type of recursive function does not match
declaration")
  | Debug(_e) ->
    string_of_tenv >>= fun str ->
    print_endline str;
    error "Debug: reached breakpoint"
  | NewRef(e) -> (* Type check e and return a reference to its type *)
    chk_expr e >>= fun t ->
    return (RefType t)
  | DeRef(e) -> (* Type check e and return its type if e is a reference *)
		chk_expr e >>= fun t ->
		(match t with
		| RefType(t_type) -> return t_type
		| _ -> error "deref: expected a reference type")
  | SetRef(e1, e2) ->
		chk_expr e1 >>= fun t1 -> (* Type checks the first expression *)
		chk_expr e2 >>= fun t2 -> (* Type checks the second expression *)
		(match t1 with
		| RefType(t1_type) -> (* If the first expression is a reference and its referred type is the same as the second expression *)
			if t1_type = t2 then return UnitType (* Return UnitType *)
			else error "setref: incompatible types"
		| _ -> error "setref: expected a reference type")
  | BeginEnd([]) -> return UnitType (* Returns a UnitType for an empty beginend *)
  | BeginEnd(es) ->
			let rec chk_exprs = function
			| [] -> return UnitType
			| [e] -> chk_expr e (* Type check only expression *)
			| e::t -> (* If there are multiple expressions, type check them all recursively *)
					chk_expr e >>= fun _ ->
					chk_exprs t
			in chk_exprs es (* Type check every expression in beginend *)
	| EmptyList(t) -> (* Returns an empty ListType with type t if t exists *)
		(match t with
		| Some t_type -> return (ListType t_type)
		| None -> error "emptylist: a type must be provided")
	| Cons(e1, e2) ->
		chk_expr e1 >>= fun t1 -> (* Type checks the first expression *)
		chk_expr e2 >>= fun t2 -> (* Type checks the second expression *)
		(match t2 with
		| ListType t2_type -> (* If the second expression is a list and its elements are the same type as the first expression *)
			if t2_type = t1 then return (ListType t1) (* Return a ListType type *)
			else error "cons: type of head and tail do not match"
		| _ -> error "cons: second argument must be a list")
	| IsEmpty(e) -> (* Type checks an expression and returns BoolType if it is a ListType or TreeType *)
		chk_expr e >>= fun t ->
		(match t with
		| ListType _ -> return BoolType
		| TreeType _ -> return BoolType
		| _ -> error "empty?: a list or tree must be provided")
	| Hd(e) -> (* Type checks an expression and returns the type of its head element if it is a ListType *)
		chk_expr e >>= fun t ->
		(match t with
		| ListType t_type -> return t_type
		| _ -> error "hd?: a list must be provided")
	| Tl(e) -> (* Type checks an expression and returns a the type of its tail if it is a ListType *)
		chk_expr e >>= fun t ->
		(match t with
		| ListType t_type -> return (ListType t_type)
		| _ -> error "tl?: a list must be provided")
	| EmptyTree(t) -> (* Returns an empty TreeType with type t if t exists *)
		(match t with
		| Some t_type -> return (TreeType t_type)
		| None -> error "emptytree: a type must be provided")
	| Node(de, le, re) ->
		chk_expr de >>= fun data_type -> (* Type check the data *)
		chk_expr le >>= fun left_type -> (* Type check the left subtree *)
		chk_expr re >>= fun right_type -> (* Type check the right subtree *)
		(match (left_type, right_type) with
		| (TreeType left_tree_type, TreeType right_tree_type) -> (* If both subtrees really are subtrees *)
			if data_type = left_tree_type && data_type = right_tree_type (* And if both subtrees are the same type as the data *)
			then return (TreeType data_type) (* Return TreeType data_type *)
			else error "node: types of data and subtrees do not match"
		| (_, _) -> error "node: both subtrees must be trees")
	| CaseT(target, emptycase, id1, id2, id3, nodecase) ->
		chk_expr target >>= fun t -> (* Type check the target *)
		(match t with
		| TreeType target_type -> (* If the target is a TreeType *)
			chk_expr emptycase >>= fun empty_type -> (* Type check the emptycase *)
			extend_tenv id1 target_type >>+	(* Extend the type environment with data id1 and subtrees id2 and id3 *)
			extend_tenv id2 (TreeType target_type) >>+
			extend_tenv id3 (TreeType target_type) >>+
			chk_expr nodecase >>= fun node_type -> (* Type check the nodecase *)
			if empty_type = node_type	(* If the type of the emptycase and nodecase are the same, return the type *)
			then return empty_type
			else error "caseT: emptycase type and nodecase type do not match"
		| _ -> error "caseT: target must be of type tree")
  | _ -> failwith "chk_expr: implement"    
and
  chk_prog (AProg(_,e)) =
  chk_expr e

(* Type-check an expression *)
let chk (e:string) : texpr result =
  let c = e |> parse |> chk_prog
  in run_teac c

let chkpp (e:string) : string result =
  let c = e |> parse |> chk_prog
  in run_teac (c >>= fun t -> return @@ string_of_texpr t)




(*
Names: Angeleanne Enriquez, Vincent Penalosa
Pledge: I pledge my honor that I have abided by the Stevens Honor System. 
*)

open ReM
open Dst
open Parser_plaf.Ast
open Parser_plaf.Parser
open List
       
let rec chk_expr : expr -> texpr tea_result = function 
  | Int _n -> return IntType
  | Var id -> apply_tenv id
  | IsZero(e) ->
    chk_expr e >>= fun t ->
    if t=IntType
    then return BoolType
    else error "isZero: expected argument of type int"
  | Add(e1,e2) | Sub(e1,e2) | Mul(e1,e2)| Div(e1,e2) ->
    chk_expr e1 >>= fun t1 ->
    chk_expr e2 >>= fun t2 ->
    if (t1=IntType && t2=IntType)
    then return IntType
    else error "arith: arguments must be ints"
  | ITE(e1,e2,e3) ->
    chk_expr e1 >>= fun t1 ->
    chk_expr e2 >>= fun t2 ->
    chk_expr e3 >>= fun t3 ->
    if (t1=BoolType && t2=t3)
    then return t2
    else error "ITE: condition not boolean or types of then and else do not match"
  | Let(id,e,body) ->
    chk_expr e >>= fun t ->
    extend_tenv id t >>+
    chk_expr body
  | Proc(var,Some t1,e) ->
    extend_tenv var t1 >>+
    chk_expr e >>= fun t2 ->
    return @@ FuncType(t1,t2)
  | Proc(_var,None,_e) ->
    error "proc: type declaration missing"
  | App(e1,e2) ->
    chk_expr e1 >>=
    pair_of_funcType "app: " >>= fun (t1,t2) ->
    chk_expr e2 >>= fun t3 ->
    if t1=t3
    then return t2
    else error "app: type of argument incorrect"
  | Letrec([(_id,_param,None,_,_body)],_target) | Letrec([(_id,_param,_,None,_body)],_target) ->
    error "letrec: type declaration missing"
  | Letrec([(id,param,Some tParam,Some tRes,body)],target) ->
    extend_tenv id (FuncType(tParam,tRes)) >>+
    (extend_tenv param tParam >>+
     chk_expr body >>= fun t ->
     if t=tRes 
     then chk_expr target
     else error
         "LetRec: Type of recursive function does not match
declaration")
  | Debug(_e) ->
    string_of_tenv >>= fun str ->
    print_endline str;
    error "Debug: reached breakpoint"
  | NewRef (e) -> 
    chk_expr e >>= fun t ->
    return (RefType t)
  | DeRef (e) -> 
    chk_expr e >>= fun t -> 
    (match t with 
    | RefType value -> return value 
    | _ -> error "deref: Expected a reference type.") 
  | SetRef (e1, e2) -> 
    chk_expr e1 >>= fun t1 -> 
    (match t1 with 
    | RefType value -> return UnitType
    | _ -> error "setref: Expected a reference type.")
  | BeginEnd ([]) -> 
    return UnitType
  | BeginEnd (es) -> 
    let rec checkList list= 
    (match list with
    | [e] -> chk_expr e
    | e::tail -> checkList tail
    | _ -> error "beginend: Can't reach the last element.")
    in checkList es
  | EmptyList (t) -> 
    (match t with 
    | Some t -> return (ListType t)
    | None -> error "empty?: Has no type given.")
  | Cons (e1, e2) -> 
    chk_expr e1 >>= fun t -> 
    chk_expr e2 >>= fun l ->
    (match l with 
    | ListType list -> if(t=list) then return (ListType list) else error "cons: type of head and tail do not match."
    | _ -> error "cons: Expected a list type.")
  | IsEmpty (e) -> 
    chk_expr e >>= fun l ->
      (match l with 
      | ListType list -> return BoolType 
      | TreeType tree -> return BoolType
      | _ -> error "isempty: Expected a list or tree type.")
  | Hd (e) -> 
    chk_expr e >>= fun l ->
      (match l with 
      | ListType list -> return list 
      | _ -> error "hd: Expected a list type.")
  | Tl (e) -> 
    chk_expr e >>= fun l ->
      (match l with 
      | ListType list -> return (ListType list)
      | _ -> error "tl: Expected a list type.")
  | EmptyTree (t) -> 
    (match t with 
    | Some t -> return (TreeType t)
    | None -> error "emptytree: Has no type given.")
  | Node (de, le, re) -> 
    chk_expr le >>= fun lt ->
    chk_expr re >>= fun rt ->
    (match (lt,rt) with 
    | (TreeType left, TreeType right) -> chk_expr de >>= fun t -> return(TreeType t) 
    | _ -> error "node: Expected tree type for le and re.")
  | CaseT (target, emptycase, id1, id2, id3, nodecase) -> 
    chk_expr target >>= fun t ->
      (match t with 
      | TreeType tree -> 
        chk_expr emptycase >>= fun s ->
        extend_tenv id1 tree >>+ 
        extend_tenv id2 (TreeType tree) >>+ 
        extend_tenv id3 (TreeType tree) >>+
        chk_expr nodecase >>= fun n ->
        if(n=s) then return s else error "caset is : Expected same type for cases."
      | _ -> error "caset: Expected a tree type.")
  | _ -> failwith "chk_expr: implement"    
  and
  chk_prog (AProg(_,e)) =
  chk_expr e

(* Type-check an expression *)
let chk (e:string) : texpr result =
  let c = e |> parse |> chk_prog
  in run_teac c

let chkpp (e:string) : string result =
  let c = e |> parse |> chk_prog
  in run_teac (c >>= fun t -> return @@ string_of_texpr t)




open Ds
open ReM
open Parser_plaf.Ast
open Parser_plaf.Parser

(*------------------------------------------------------------------------------*
  SOOL+ Interpreter
  - Adds: instanceOf?(e,id) predicate
  - Supports: method overloading via name mangling
 *------------------------------------------------------------------------------*)

(*AST helpers and class environment types*)

(* method_decl: parameter names * method body * superclass name * visible fields *)
type method_decl = string list * expr * string * string list

type method_env  = (string * method_decl) list

type class_decl   = string * string list * method_env

type class_env    = (string * class_decl) list

(* Global store and class env *)
let g_store     = Store.empty_store 20 (NumVal 0)
let g_class_env : class_env ref = ref []

(*-name mangling for overloading*)
let name_mangle (mname:string) (args:expr list) : string =
  mname ^ "_" ^ string_of_int (List.length args)

(*building class environment with mangled method names*)
let initialize_class_env (cs:cdecl list) : unit =
  (* collect inherited fields for class 'name' *)
  let rec collect_fields name = function
    | [] -> failwith ("superclass not found: "^name)
    | Class(n,sup,iface,fields,_)::rest when n=name ->
      List.map fst fields @ (if sup="" then [] else collect_fields sup cs)
    | _::rest -> collect_fields name rest
  in
  (* collect methods (mangled) for class 'name' *)
  let rec collect_methods name = function
    | [] -> failwith ("superclass not found: "^name)
    | Class(n,sup,iface,_,methods)::rest when n=name ->
      let own = List.map (fun (Method(nm,_,pars,body)) ->
        let key = name_mangle nm pars in
        (key, (List.map fst pars, body, sup, collect_fields n cs))) methods in
      own @ (if sup="" then [] else collect_methods sup cs)
    | _::rest -> collect_methods name rest
  in
  (* initialize global env, start with 'object' *)
  g_class_env := [("object", ("", [], []))];
  List.iter (function
    | Class(name,super,iface,fields,methods) ->
      let fs = collect_fields name cs in
      let ms = collect_methods name cs in
      g_class_env := (name, (super, fs, ms)) :: !g_class_env
    | Interface _ -> ()
  ) cs

(*subclass check for instanceOf?*)
let is_subclass (sub:string) (sup:string) (cenv:class_env) : exp_val ea_result =
  fun _env ->
    if not (List.mem_assoc sup cenv) then
      Error ("is_subclass : class "^sup^" not found")
    else
      let rec loop name =
        if name=sup then Ok (BoolVal true) else
        match List.assoc_opt name cenv with
        | None -> Error ("is_subclass : class "^name^" not found")
        | Some (parent,_,_) ->
          if parent="" then Ok (BoolVal false)
          else loop parent
      in loop sub

(*method lookup and invocation (overloaded)*)
let lookup_method class_name mkey cenv : method_decl option =
  match List.assoc_opt class_name cenv with
  | None -> None
  | Some (_,_,ms) -> List.assoc_opt mkey ms

let rec slice fs env =
  (* building environment with only fields fs present *)
  let rec aux = function
    | [], acc -> acc
    | id::ids, acc ->
      (match acc with
       | ExtendEnv(v,ev,tail) when v=id -> ExtendEnv(v,ev,aux (ids,tail))
       | ExtendEnv(_,_,tail) -> aux (id::ids, tail)
       | EmptyEnv -> failwith "slice: missing field"
       | ExtendEnvRec _ -> failwith "slice: unexpected rec env")
  in return (aux (List.rev fs, env))

let rec new_env fields =
  (* allocating fresh ref for each field *)
  let rec aux = function
    | [] -> lookup_env
    | id::ids -> extend_env id (RefVal (Store.new_ref g_store (NumVal 0))) >>+ aux ids
  in aux fields

let rec apply_method mkey self args (pars,body,super,fields) =
  if List.length args <> List.length pars then
    error (mkey ^ ": args and params have different lengths")
  else
    obj_of_objectVal self >>= fun (_, env0) ->
    slice fields env0 >>+ fun env1 ->
    (* binding super, self, parameters *)
    let super_loc = Store.new_ref g_store (StringVal super) in
    let self_loc  = Store.new_ref g_store self in
    let arg_locs  = List.map (fun ev -> RefVal (Store.new_ref g_store ev)) args in
    extend_env_list ("_super"::"_self"::pars) ((RefVal super_loc)::(RefVal self_loc)::arg_locs) >>+
    eval_expr body

(*core evaluator*)

and eval_expr : expr -> exp_val ea_result = fun e -> match e with
  (* literals *)
  | Int n      -> return (NumVal n)
  | Var id     -> apply_env id >>= int_of_refVal >>= Store.deref g_store

  (* arithmetic *)
  | Add(e1,e2) -> eval_expr e1 >>= int_of_numVal >>= fun n1 -> eval_expr e2 >>= int_of_numVal >>= fun n2 -> return (NumVal (n1+n2))
  | Sub(e1,e2) -> eval_expr e1 >>= int_of_numVal >>= fun n1 -> eval_expr e2 >>= int_of_numVal >>= fun n2 -> return (NumVal (n1-n2))
  | Mul(e1,e2) -> eval_expr e1 >>= int_of_numVal >>= fun n1 -> eval_expr e2 >>= int_of_numVal >>= fun n2 -> return (NumVal (n1*n2))
  | Div(e1,e2) -> eval_expr e1 >>= int_of_numVal >>= fun n1 -> eval_expr e2 >>= int_of_numVal >>= fun n2 -> if n2=0 then error "Division by zero" else return (NumVal (n1/n2))

  (* control *)
  | ITE(cond,t,e2) -> eval_expr cond >>= bool_of_boolVal >>= fun b -> if b then eval_expr t else eval_expr e2
  | IsZero e1      -> eval_expr e1 >>= int_of_numVal >>= fun n -> return (BoolVal (n=0))

  (* variable binding *)
  | Let(v,d,b)     -> eval_expr d >>= fun dv -> let l=Store.new_ref g_store dv in extend_env v (RefVal l) >>+ eval_expr b
  | Letrec(decs,b) ->
    (match decs with
     | [(id,par,_,_,body)] ->
       let loc = Store.new_ref g_store UnitVal in
       extend_env id (RefVal loc) >>+
       (lookup_env >>= fun env0 -> Store.set_ref g_store loc (ProcVal(par,body,env0)) >>= fun _ -> eval_expr b)
     | _ -> failwith "multiple letrec not supported")

  (* sequencing *)
  | BeginEnd([])   -> return UnitVal
  | BeginEnd(es)   -> eval_exprs es >>= fun vs -> return (List.hd (List.rev vs))

  (* instanceOf? *)
  | IsInstanceOf(e1, cid) -> eval_expr e1 >>= obj_of_objectVal >>= fun (cname,_) -> is_subclass cname cid !g_class_env >>= fun (BoolVal b) -> return (BoolVal b)

  (* object operations *)
  | NewObject(cname, args) ->
    eval_exprs args >>= fun avals ->
    (match List.assoc_opt cname !g_class_env with
     | None -> error ("NewObject: class not found: "^cname)
     | Some (sup, fields, methods) ->
       new_env fields >>+ fun env0 ->
       let obj = ObjectVal(cname, env0) in
       (match List.assoc_opt (name_mangle "initialize" []) methods with
        | None -> return obj
        | Some m  -> apply_method (name_mangle "initialize" []) obj [] m >>= fun _ -> return obj))

  | Send(e0, mname, args) ->
    eval_expr e0 >>= fun selfv ->
    obj_of_objectVal selfv >>= fun (cname,_) ->
    eval_exprs args  >>= fun avals  ->
    let key = name_mangle mname args in
    (match lookup_method cname key !g_class_env with
     | None -> error ("Send: method not found: "^mname)
     | Some m -> apply_method key selfv avals m)

  | Super(mname, args) ->
    eval_expr (Var "_super") >>= string_of_stringVal >>= fun super_c ->
    eval_expr (Var "_self")   >>= fun selfv    ->
    eval_exprs args            >>= fun avals    ->
    let key = name_mangle mname args in
    (match lookup_method super_c key !g_class_env with
     | None -> error ("Super: method not found: "^mname)
     | Some m -> apply_method key selfv avals m)

  | Self -> eval_expr (Var "_self")

  | Debug _ ->
    string_of_env >>= fun senv ->
    let sst = Store.string_of_store string_of_expval g_store in
    print_endline (senv^"\n"^sst);
    error "Debug: breakpoint reached"

  | _ -> failwith ("eval_expr: not implemented: "^string_of_expr e)

and eval_exprs es =
  sequence (List.map eval_expr es)

and eval_prog (AProg(cs,e)) =
  initialize_class_env cs;
  eval_expr e

let interpf file = run (parsef file |> eval_prog)

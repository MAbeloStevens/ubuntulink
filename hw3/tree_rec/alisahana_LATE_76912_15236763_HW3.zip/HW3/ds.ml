(*
Adrian Lee | Sahana Ali

I pledge my honor that I have abided by the Stevens Honor System.

ds.ml

EXTENSION TILL MARCH 10TH 11:59 WAS APPROVED BY PROFESSOR BERNOUILLI
*)


type 'a tree = 
  | Empty 
  | Node of 'a * 'a tree * 'a tree

type exp_val =
  | NumVal of int
  | BoolVal of bool
  | PairVal of exp_val * exp_val
  | TupleVal of exp_val list
  | TreeVal of exp_val tree

type env =
  | EmptyEnv
  | ExtendEnv of string * exp_val * env

 

type 'a result = Ok of 'a | Error of string

type 'a ea_result = env -> 'a result
  
let return : 'a -> 'a ea_result =
  fun v _env -> Ok v

let error : string -> 'a ea_result = fun s _env -> Error s

let (>>=) : 'a ea_result -> ('a -> 'b ea_result) -> 'b ea_result = 
  fun c f env ->
    match c env with
    | Error err -> Error err
    | Ok v -> f v env

let (>>+) : env ea_result -> 'a ea_result -> 'a ea_result =
  fun c d env ->
    match c env with
    | Error err -> Error err
    | Ok newenv -> d newenv

let run : 'a ea_result -> 'a result =
  fun c -> c EmptyEnv

let lookup : env ea_result = fun env -> Ok env

let rec sequence : 'a ea_result list -> 'a list ea_result =
  function
  | [] -> return []
  | h::t -> 
      h >>= fun ev ->
      sequence t >>= fun evs ->
      return (ev::evs)

 

let empty_env () = return EmptyEnv

let extend_env id v env = Ok (ExtendEnv (id, v, env))

let rec extend_env_list_helper ids evs en =
  match ids, evs with
  | [], [] -> en
  | id::idt, ev::evt -> ExtendEnv (id, ev, extend_env_list_helper idt evt en)
  | _, _ -> failwith "extend_env_list_helper: ids and evs have different sizes"

let extend_env_list ids evs en = Ok (extend_env_list_helper ids evs en)

let rec apply_env id env =
  match env with
  | EmptyEnv -> Error (id ^ " not found!")
  | ExtendEnv (v, ev, tail) -> if id = v then Ok ev else apply_env id tail

 

let int_of_numVal = function
  | NumVal n -> return n
  | _ -> error "Expected a number!"

let bool_of_boolVal = function
  | BoolVal b -> return b
  | _ -> error "Expected a boolean!"

let list_of_tupleVal = function
  | TupleVal l -> return l
  | _ -> error "Expected a tuple!"

let pair_of_pairVal = function
  | PairVal (ev1, ev2) -> return (ev1, ev2)
  | _ -> error "Expected a pair!"

 

let rec string_of_expval = function
  | NumVal n -> "NumVal " ^ string_of_int n
  | BoolVal b -> "BoolVal " ^ string_of_bool b
  | PairVal (ev1, ev2) -> "PairVal(" ^ string_of_expval ev1 ^ ", " ^ string_of_expval ev2 ^ ")"
  | TupleVal evs -> "TupleVal(" ^ String.concat ", " (List.map string_of_expval evs) ^ ")"
  | TreeVal t -> "TreeVal(" ^ string_of_tree t ^ ")"

and string_of_tree = function
  | Empty -> "Empty"
  | Node (value, left, right) ->
      "Node(" ^ string_of_expval value ^ ", " ^ string_of_tree left ^ ", " ^ string_of_tree right ^ ")"

let rec string_of_env' ac = function
  | EmptyEnv -> "[" ^ String.concat ",\n" ac ^ "]"
  | ExtendEnv (id, v, env) -> string_of_env' ((id ^ ":=" ^ string_of_expval v) :: ac) env

let string_of_env : string ea_result =
  fun env ->
    match env with
    | EmptyEnv -> Ok ">>Environment:\nEmpty"
    | _ -> Ok (">>Environment:\n" ^ string_of_env' [] env)

(*Name: Anthony Eryan
Pledge: I pledge my honor that I have abided by the Stevens Honor System. -A. Eryan*)
open Parser_plaf.Ast
open Parser_plaf.Parser
open Ds
    
(** [eval_expr e] evaluates expression [e] *)
let rec eval_expr : expr -> exp_val ea_result =
  fun e ->
  match e with
  | Int(n) ->
    return (NumVal n)
  | Var(id) ->
    apply_env id
  | Add(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return (NumVal (n1+n2))
  | Sub(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return (NumVal (n1-n2))
  | Mul(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return (NumVal (n1*n2))
  | Div(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    if n2==0
    then error "Division by zero"
    else return (NumVal (n1/n2))
  | Let(id,def,body) ->
    eval_expr def >>= 
    extend_env id >>+
    eval_expr body 
  | ITE(e1,e2,e3) ->
    eval_expr e1 >>=
    bool_of_boolVal >>= fun b ->
    if b 
    then eval_expr e2
    else eval_expr e3
  | IsZero(e) ->
    eval_expr e >>=
    int_of_numVal >>= fun n ->
    return (BoolVal (n = 0))
  | EmptyTree (_t) -> return (TreeVal Empty)
  | Node(e1, e2, e3) -> 
    eval_expr e2 >>= (*pattern match e2 to tree_of_treeVal*)
    tree_of_treeVal >>= fun t2 -> (*if truly a tree, save it as a parameter variable*)
    eval_expr e3 >>= (*pattern match e3 to tree_of_treeVal*)
    tree_of_treeVal >>= fun t3 ->
    eval_expr e1 >>= fun all -> (*declared as all since the data can be either one of exp_val in ds.ml*)
    return (TreeVal (Node(all, t2, t3)))
  | IsEmpty(e) ->
    eval_expr e >>= tree_of_treeVal >>= fun t ->
    (match t with 
    |Empty -> return (BoolVal(true))
    | _ -> return (BoolVal(false)))
  | CaseT(e1, e2, id1, id2, id3, e3) ->   (*id1-id3 are variables like the x in let x, but for TreeVal*)
    eval_expr e1 >>= 
    tree_of_treeVal (*checks if valid tree*) >>= fun t -> (*match with the eval'd e1*)
    (match t with
    | Empty ->  eval_expr e2 (*do e2*)
    | Node(data,l, r) -> 
      extend_env id1 data >>+ (*extend environment via assigning the value into each variable*) 
      extend_env id2 (TreeVal l) >>+
      extend_env id3 (TreeVal r) >>+
      eval_expr e3 (*otherwise, do e3*)
    )
  | Record(fs) ->
    let rec check_duplicates = function
      | [] -> return true
      | (id, _)::rest ->
        if List.exists (fun (id', _) -> id = id') rest
        then error "Record: duplicate fields"
        else check_duplicates rest
    in
    check_duplicates fs >>= fun _ ->
    let rec eval_fields = function
      | [] -> return []
      | (id, (b, e))::rest ->
        eval_expr e >>= fun v ->
        eval_fields rest >>= fun fields ->
        return ((id, (b, v))::fields)
    in
    eval_fields fs >>= fun fields ->
    return (RecordVal fields)

    | Proj(e, id) ->
      eval_expr e >>= fun ev ->
      (match ev with
      | RecordVal fields ->
        let rec find_field = function
          | [] -> error "Proj: field does not exist"
          | (id', (_, v))::rest ->
            if id = id' then return v
            else find_field rest
        in
        find_field fields
      | _ -> error "Expected a record"
      )  (* Note: explicit parentheses *)
    
    | Debug(_e) ->
      string_of_env >>= fun str ->
      print_endline str;
      error "Debug called"

  | _ -> failwith "Not implemented yet!"

(** [eval_prog e] evaluates program [e] *)
let eval_prog (AProg(_,e)) =
  eval_expr e

(** [interp s] parses [s] and then evaluates it *)
let interp (e:string) : exp_val result =
  let c = e |> parse |> eval_prog
  in run c
  



(*Names: Angeleanne Enriquez, Vincent Penalosa 
Pledge: I pledge my honor that I have abided by the Stevens Honor System. 
*)

open Parser_plaf.Ast
open Parser_plaf.Parser
open Ds
open List    

(** [eval_expr e] evaluates expression [e] *)
let rec eval_expr : expr -> exp_val ea_result =
  fun e ->
  match e with
  | Int(n) ->
    return (NumVal n)
  | Var(id) ->
    apply_env id
  | Add(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return (NumVal (n1+n2))
  | Sub(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return (NumVal (n1-n2))
  | Mul(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return (NumVal (n1*n2))
  | Div(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    if n2==0
    then error "Division by zero"
    else return (NumVal (n1/n2))
  | Let(id,def,body) ->
    eval_expr def >>= 
    extend_env id >>+
    eval_expr body 
  | ITE(e1,e2,e3) ->
    eval_expr e1 >>=
    bool_of_boolVal >>= fun b ->
    if b 
    then eval_expr e2
    else eval_expr e3
  | IsZero(e) ->
    eval_expr e >>=
    int_of_numVal >>= fun n ->
    return (BoolVal (n = 0))
  | Debug(_e) ->
    string_of_env >>= fun str ->
    print_endline str; 
    error "Debug called"
  | IsEmpty (e) -> 
    eval_expr e >>= 
    tree_of_TreeVal >>= fun t -> 
    if t=Empty 
    then return (BoolVal (true))
    else return (BoolVal (false)) 
  | EmptyTree (_t) -> return (TreeVal (Empty)) 
  | Node (e1, e2, e3) -> 
    eval_expr e1 >>= fun a ->
    eval_expr e2 >>= 
    tree_of_TreeVal >>= fun l ->
    eval_expr e3 >>= 
    tree_of_TreeVal >>= fun r -> 
    return (TreeVal(Node(a,l,r))) 
  | CaseT (e1, e2, id1, id2, id3, e3) -> 
    eval_expr e1 >>= 
    tree_of_TreeVal >>= fun t ->
    (match t with 
    | Empty -> eval_expr e2
    | Node(a,l,r) -> extend_env id1 a >>+ 
      extend_env id2 (TreeVal (l)) >>+ 
      extend_env id3 (TreeVal (r)) >>+
      eval_expr e3)
  | Record (fs) -> 
    let fields = map fst fs in 
    let dupFields = remove_all_dups fields in 
    if length fields > length dupFields 
    then error "Record: duplicate fields"
    else 
      let rec createRecord l = 
        match l with 
        | [] -> return []
        | (name,(_,value))::t -> 
          eval_expr value >>= fun v ->
          createRecord t >>= fun t ->
          return ((name,(false,v))::t)
      in 
      createRecord fs >>= fun r ->
      return (RecordVal(r))
  | Proj (e, id) -> 
    eval_expr e >>= 
    record_of_RecordVal >>= fun r -> 
    projector r id
  | _ -> failwith "Implement me!"
and
  eval_exprs : expr list -> (exp_val list) ea_result =
  fun es ->
  match es with
  | [] -> return []
  | h::t -> eval_expr h >>= fun i ->
    eval_exprs t >>= fun l ->
    return (i::l)

(** [eval_prog e] evaluates program [e] *)
let eval_prog (AProg(_,e)) =
  eval_expr e

(** [interp s] parses [s] and then evaluates it *)
let interp (e:string) : exp_val result =
  let c = e |> parse |> eval_prog
  in run c

(*interp 
"let t=node(0,node(521,emptytree(),node(0,emptytree(),emptytree())),node(5-4,node(104,emptytree(),emptytree()),node(0,node(9,emptytree(),emptytree()),emptytree())))
in
 caseT t of {
    emptytree () -> 10 ,
    node (a, l, r) -> 
        if zero?(a) then
            caseT l of {
                emptytree () -> 21 ,
                node (b, ll, rr) -> if zero?(b) then 4 else 99
            }
        else 5}";;*)
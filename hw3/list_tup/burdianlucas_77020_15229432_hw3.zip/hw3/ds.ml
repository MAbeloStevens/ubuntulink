(* ds.ml - Helper functions for Lists and Tuples *)

open Ea_result  (* Importing result-handling utilities *)

(* Define possible expression values *)
type exp_val =
  | NumVal of int  (* Integer value *)
  | BoolVal of bool  (* Boolean value *)
  | ListVal of exp_val list  (* List value containing expressions *)
  | TupleVal of exp_val list  (* Tuple value containing multiple expressions *)

(* Convert expression values to strings for debugging and testing *)
let rec string_of_exp_val = function
  | NumVal n -> string_of_int n
  | BoolVal b -> string_of_bool b
  | ListVal l -> "[" ^ String.concat "; " (List.map string_of_exp_val l) ^ "]"
  | TupleVal t -> "(" ^ String.concat ", " (List.map string_of_exp_val t) ^ ")"

(* Extend the environment with multiple identifier-value bindings for tuples *)
let extend_env_list ids vals =
  match List.combine_opt ids vals with
  | Some bindings -> extend_env bindings  (* Bind each identifier to a value if lengths match *)
  | None -> error "Mismatched tuple lengths"  (* Error if lengths do not match *)



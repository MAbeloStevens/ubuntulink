
(* interp.ml - Implementation of eval_expr for Lists and Tuples *)

open Ds  (* Importing helper functions from ds.ml *)

(* Main interpreter function: eval_expr *)
let rec eval_expr : expr -> exp_val ea_result = function
  | Int n -> return (NumVal n)  (* Integer case: return a NumVal *)
  | Bool b -> return (BoolVal b)  (* Boolean case: return a BoolVal *)
  | EmptyList _ -> return (ListVal [])  (* Create an empty list *)
  
  (* Construct a list by adding an element to an existing list *)
  | Cons (e1, e2) ->
      eval_expr e1 >>= fun v1 ->  (* Evaluate first expression (head) *)
      eval_expr e2 >>= fun v2 ->  (* Evaluate second expression (tail) *)
      (match v2 with
       | ListVal l -> return (ListVal (v1 :: l))  (* Append to list if valid *)
       | _ -> error "Second argument to cons must be a list")  (* Error if second argument isn't a list *)
  
  (* Extract the head of a list, return an error if empty or invalid *)
  | Hd e ->
      eval_expr e >>= (function
          | ListVal (h::_) -> return h  (* Return first element if available *)
          | ListVal [] -> error "Empty list has no head"  (* Error on empty list *)
          | _ -> error "Argument must be a list")  (* Error if not a list *)
  
  (* Extract the tail of a list, return an error if empty or invalid *)
  | Tl e ->
      eval_expr e >>= (function
          | ListVal (_::t) -> return (ListVal t)  (* Return the tail if available *)
          | ListVal [] -> error "Empty list has no tail"  (* Error on empty list *)
          | _ -> error "Argument must be a list")  (* Error if not a list *)
  
  (* Check if a list is empty, return a boolean value *)
  | IsEmpty e ->
      eval_expr e >>= (function
          | ListVal [] -> return (BoolVal true)  (* True if empty *)
          | ListVal _ -> return (BoolVal false)  (* False if not empty *)
          | _ -> error "Argument must be a list")  (* Error if not a list *)
  
  (* Evaluate a tuple expression by evaluating each component *)
  | Tuple es ->
      sequence (List.map eval_expr es) >>= fun vals ->  (* Evaluate all elements in tuple *)
      return (TupleVal vals)  (* Return evaluated tuple *)
  
  (* Handle tuple unpacking by matching elements to identifiers *)
  | LetTuple (ids, e1, e2) ->
      eval_expr e1 >>= (function
          | TupleVal vs when List.length vs = List.length ids ->
              extend_env_list ids vs >>+  (* Extend the environment with new bindings *)
              eval_expr e2  (* Evaluate the expression under the new environment *)
          | _ -> error "Tuple matching error")  (* Error if tuple structure is mismatched *)
  
  (* Default case: if an expression is not implemented, return an error *)
  | _ -> error "Expression not implemented"



open Parser_plaf.Ast
open Parser_plaf.Parser
open Ds
    
(** [eval_expr e] evaluates expression [e] *)
let rec eval_expr : expr -> exp_val ea_result =
  fun e ->
  match e with
  | Int(n) ->
    return (NumVal n)
  | Var(id) ->
    apply_env id
  | Add(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return (NumVal (n1+n2))
  | Sub(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return (NumVal (n1-n2))
  | Mul(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return (NumVal (n1*n2))
  | Div(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    if n2==0
    then error "Division by zero"
    else return (NumVal (n1/n2))
  | Let(id,def,body) ->
    eval_expr def >>= 
    extend_env id >>+
    eval_expr body 
  | ITE(e1,e2,e3) ->
    eval_expr e1 >>=
    bool_of_boolVal >>= fun b ->
    if b 
    then eval_expr e2
    else eval_expr e3
  | IsZero(e) ->
    eval_expr e >>=
    int_of_numVal >>= fun n ->
    return (BoolVal (n = 0))
  | Debug(_e) ->
    string_of_env >>= fun str ->
    print_endline str; 
    error "Debug called"
  
  
  (* List Operators *)
  (* Adds an element to a list *)
  | Cons(e1, e2) ->
    eval_expr e1 >>= fun head ->
    eval_expr e2 >>= fun tail ->
    (* If the tail is not empty, get list from it and add head to the tail *)
    if not (tail = ListVal []) 
    then let ListVal lst = tail in
    return (ListVal (head::lst))
    (* If the tail is empty, return only the head *)
    else if tail = ListVal [] 
    then return (ListVal [head])
    else error "Not a list"
  (* Returns the head of a list *)
  | Hd(e) ->
    eval_expr e >>= fun value -> 
    (* If value is an empty list, return error *)
    if value = ListVal [] 
    then error "Empty list"
    (* Return the head of the list otherwise *)
    else (match value with
    | ListVal (h::_) -> return h
    | _ -> error "Not a list")
  (* Returns the tail of a list *)
  | Tl(e) ->
    eval_expr e >>= fun value -> 
    (* If value is an empty list, return error *)
    if value = ListVal [] 
    then error "Empty list"
    (* Return the tail of the list *)
    else (match value with
    | ListVal (_::tail) -> return (ListVal tail)
    | _ -> error "Not a list")
  (* Checks whether a list is empty or not *)
  | IsEmpty(e) ->
    eval_expr e >>= fun value ->
    (* If value is an empty list, return true *)
    if value = ListVal [] 
    then return (BoolVal true)
    (* If vavlue is not an empty list, return false *)
    else if (match value with ListVal _ -> true | _ -> false) 
    then return (BoolVal false)
    else return (BoolVal false)
  (* Creates an empty list *)
  | EmptyList(_) -> return (ListVal [])

  (* Tuple Operators *)
  (* Creates a tuple *)
  | Tuple(es) -> 
    eval_exprs es >>= fun vals -> 
    return (TupleVal vals)
  (* Evaluates e1, makes sure it is a tuple, extracts and binds each component to ids, and evaluates e2 under the extended environment *)
  | Untuple(ids, e1, e2) ->
    eval_expr e1 >>= (fun result ->
    (* If result is a tuple of matching lengths, extend the environment with its ids and values *)
    match result with
    | TupleVal vals when List.length ids = List.length vals ->
        extend_env_list ids vals >>+ eval_expr e2
    | TupleVal _ -> error "extend_env_list: Arguments do not match parameter"
    | _ -> error "Expected a tuple!"
  )


(** Evaluates a list of expressions *)
and eval_exprs es =
  match es with
  | [] -> return []
  | h :: t -> eval_expr h >>= fun v ->
              eval_exprs t >>= fun vs ->
              return (v :: vs)


(** [eval_prog e] evaluates program [e] *)
let eval_prog (AProg(_,e)) =
  eval_expr e

(** [interp s] parses [s] and then evaluates it *)
let interp (e:string) : exp_val result =
  let c = e |> parse |> eval_prog
  in run c
  



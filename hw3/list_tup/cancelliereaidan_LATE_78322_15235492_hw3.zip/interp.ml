open Parser_plaf.Ast
open Parser_plaf.Parser
open Ds
    
(*
  CS 496 - HW3
  Aidan Cancelliere
*)

(** [eval_expr e] evaluates expression [e] *)
let rec eval_expr : expr -> exp_val ea_result =
  fun e ->
  match e with
  | Int(n) ->
    return (NumVal n)
  | Var(id) ->
    apply_env id
  | Add(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return (NumVal (n1+n2))
  | Sub(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return (NumVal (n1-n2))
  | Mul(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return (NumVal (n1*n2))
  | Div(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    if n2==0
    then error "Division by zero"
    else return (NumVal (n1/n2))
  | Let(id,def,body) ->
    eval_expr def >>= 
    extend_env id >>+
    eval_expr body 
  | ITE(e1,e2,e3) ->
    eval_expr e1 >>=
    bool_of_boolVal >>= fun b ->
    if b 
    then eval_expr e2
    else eval_expr e3
  | IsZero(e) ->
    eval_expr e >>=
    int_of_numVal >>= fun n ->
    return (BoolVal (n = 0))
  | Debug(_e) ->
    string_of_env >>= fun str ->
    print_endline str; 
    error "Debug called"
  | Cons(e1, e2) -> 
    eval_expr e1 >>= fun element ->
    eval_expr e2 >>= fun list_value ->
    (match list_value with
      | TupleVal l -> return (TupleVal (element::l))
      | _ -> error "Cons(e1,e2): 'e2' arguement is not a list")
  | Hd(e) -> 
    eval_expr e >>= fun list_value ->
    (match list_value with 
      | TupleVal (h::_) -> return h
      | TupleVal [] -> error "Hd(e): empty list, no head can be returned"
      | _ -> error "Hd(e): 'e' arguement is not a list")
  | Tl(e) -> 
    eval_expr e >>= fun list_value ->
    (match list_value with 
      | TupleVal (_::t) -> return (TupleVal t)
      | TupleVal [] -> error "Tl: 'e' arguement is an empty list, no tail can be returned"
      | _ -> error "Tl(e): 'e' arguement is not a list")
  | IsEmpty(e) -> 
    eval_expr e >>= fun list_value ->
    (match list_value with 
      | TupleVal l -> return (BoolVal (l = []))
      | _ -> error "IsEmpty(e): 'e' arguement is not a list")
  | EmptyList(_t) -> 
    return (TupleVal [])
  | Tuple(es) ->
    eval_exprs es >>= fun evaluated_values ->
    return (TupleVal evaluated_values)
  | Untuple(ids, e1, e2) ->
    eval_expr e1 >>= fun tuple_val ->
    (match tuple_val with
      | TupleVal value_list ->
          if List.length ids <> List.length value_list then (* Check the tuple has the expected number of components*)
            error "Untuple(ids, e1, e2): ids and tuple length do not match"
          else
            extend_env_list ids value_list >>+ eval_expr e2 (* Extend the environment with each binding, then eval e2*)
      | _ -> error "Untuple(ids, e1, e2): expression is not a tuple")
  | _ -> failwith "Not implemented yet!"  
and
  eval_exprs : expr list -> (exp_val list) ea_result =
  fun es ->
  match es with
  | [] -> return []
  | h::t -> eval_expr h >>= fun i ->
    eval_exprs t >>= fun l ->
    return (i::l)


(** [eval_prog e] evaluates program [e] *)
let eval_prog (AProg(_,e)) =
  eval_expr e

(** [interp s] parses [s] and then evaluates it *)
let interp (e:string) : exp_val result =
  let c = e |> parse |> eval_prog
  in run c  
